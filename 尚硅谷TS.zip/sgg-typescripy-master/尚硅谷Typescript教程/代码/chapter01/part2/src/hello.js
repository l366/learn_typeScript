console.log('Hello');

let hh = 10;
// hh = 'hello';